
<!DOCTYPE HTML>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="css/Search%20Book%20Result.css"/>
</head>
<body>

<header>
    <div class="head_top">
        <div class="logo_name"><img class="siyanelogo" src="images/siyane_logo.jpg">

            <h1>LIBRARY</h1>
            <h3>Siyane National College of Education<br />Veyangoda</h3>

        </div>
    </div>
    <div class="bgimage">
        <nav>
            <ul>
                <li><a href="Member%20Page.html">HOME</a></li>
            </ul>
        </nav>
    </div>
</header>



<div style="overflow:auto;">
    <table style="width:100%">
        <caption>Searched Book Reuslt</caption>
        <tr>
            <th>Accession No</th>
            <th>Category No</th>
            <th>Title</th>
            <th>Author</th>
            <th>Book Type</th>
            <th>Availability</th>
        </tr>

        <tr>
            <td>150377G</td>
            <td>A.S.Madhushanki</td>
            <td>1995/NOV/27</td>
            <td>Gampaha</td>
            <td>pending</td>
            <td>available</td>
            <td>3</td>

        </tr>

    </table>
</div>

</body>
</html>

