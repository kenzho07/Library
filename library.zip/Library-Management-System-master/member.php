<?php


class member extends table{
   var $id=null;
   var $member_name=null;
   var $member_fullname=null;
   var $member_type=null;
   var $join_date=null;
   var $addmission_date=null;
   var $permanent_address=null;
   var $current_address=null;
   var $member_email=null;
   var $contact_no=null;
   var $member_status=null;
   var $tableName="members";

}

?>