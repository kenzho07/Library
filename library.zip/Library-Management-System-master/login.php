<?php


class login extends table
{
    var $id=null;
    var $password=null;
    var $last_login_date=null;
    var $tableName="logins";
}
?>