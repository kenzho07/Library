<?php
class book extends table{
    var $title=null;
    var $id=null;
    var $ISBN=null;
    var $author=null;
    var $category_no=null;
    var $publisher_name=null;
    var $published_date=null;
    var $publisher_address=null;
    var $price=null;
    var $no_pages=null;
    var $date_added=null;
    var $book_type=null;
    var $book_status=null;
    var $remarks=null;
    var $tableName="books";

}


?>

