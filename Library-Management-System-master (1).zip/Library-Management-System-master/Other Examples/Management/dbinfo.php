<?php

$username = 'root';
$password = '';
$host = 'localhost';   
$database = 'Corporate';

?>