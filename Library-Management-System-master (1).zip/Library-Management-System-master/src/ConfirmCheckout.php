<html>
<body>
<h1>Checkout Success</h1>
<form action="UserSummary.php" method="post">
<input type="submit" value="Back"/>
</form>
</body>
</html>
